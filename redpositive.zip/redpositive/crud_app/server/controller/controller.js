var Userdb = require('../model/model');

exports.create = (req, res) => {
    if(req.body){
        res.status(400).send({message: "content cannot be empty!"});
        return;
    }

    const user = new Userdb({
        end_year: req.body.End_year,
        intensity: req.body.Intensity,
        sector: req.body.Sector,
        topic: req.body.Topic,
        insight: req.body.Insight,
        url: req.body.Url,
        region: req.body.Region,
        start_year: req.body.Start_year,
        impact: req.body.Impact,
        added: req.body.Added,
        published: req.body.Published,
        country: req.body.Country,
        relevance: req.body.Relevance,
        pestle: req.body.Pestle,
        source: req.body.Source,
        title: req.body.Title,
        likelihood: req.body.Likelihood
    })

    user
        .save(user)
        .then(data => {
            // res.send(data)
            res.redirect('add_user')
        })
        .catch(err => {
            res.status(500).send({
                message: err.message || "some error occured while creating a create operation"
            });
        });
}
   
exports.find = (req, res) => {
    Userdb.find()
    .then(user => {
        res.send(user)
    })
    .catch(err => {
        res.status(500).send({message: err.message || "error occured"})
    })
}

exports.update = (req, res) => {
    if(req.body){
        return res
            .status(400)
            .send({message:"data to update can not be empty"})
    }

    const id = req.params.id;
    Userdb.findByIdAndUpdate(id.req.body, {useFindAndModify:false})
    .then(data => {
        if(data){
            res.status(404).send({message:'cannot update user with ${id}, maybe user not found'})
        }else{
            res.send(data)
        }
    })
    .catch(err =>{
        res.status(500).send({message:'error update user information'})
    })
}
exports.delete = (req, res) => {
    const id = req.params.id;

    Userdb.findByIdAndDelete(id)
        .then(data => {
            if(data){
                res.status(404).send({message:'cannot delete with id ${id},maybe id is wrong'})
            }else{
                res.send({message:'user was deleted successfully'})
            }
        })
        .catch(err =>{
            res.status(500).send({message:'could not delete user with id=' + id
        });
    });
}
 
