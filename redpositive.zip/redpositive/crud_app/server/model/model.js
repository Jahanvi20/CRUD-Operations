const mongoose = require('mongoose');

var schema = new mongoose.Schema({
    ID: {
        type: String,
        required: true
    },
    Name: {
        type: String,
        required: true
    },
    Phone_Number: {
        type: String,
        required: true
    },
    Email: {
        type: String,
        required: true
    },
    Hobbies: {
        type: String,
        required: true
    },
    Update_Delete: {
        type: String,
        required: true
    },
    
})

const Userdb = mongoose.model('userdb',schema);

module.exports = Userdb;